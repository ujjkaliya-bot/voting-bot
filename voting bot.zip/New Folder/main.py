import os
import logging
from aiogram import Bot, Dispatcher, executor, types
from dotenv import load_dotenv
from utils.keyboards import get_main_menu

load_dotenv()
logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.getenv("BOT_TOKEN")
bot = Bot(token=BOT_TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    welcome_text = (
        "👋 <b>WELCOME TO LOOTVERSE VOTE GIVEAWAY BOT</b>\n\n"
        "⚡ <i>Create Powerful Vote Giveaways</i>\n"
        "📈 <i>Real Time Vote System</i>\n"
        "🛠️ <i>Advanced Management Tools</i>\n"
        "🏆 <i>Leaderboard & Analytics</i>\n\n"
        "🚀 <b>START CREATING NOW!</b>"
    )
    await message.reply(welcome_text, reply_markup=get_main_menu())

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
