from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_main_menu() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(InlineKeyboardButton(text="📁 CONNECT", callback_data="btn_connect"))
    keyboard.row(
        InlineKeyboardButton(text="➕ CREATE", callback_data="btn_create"),
        InlineKeyboardButton(text="⚡ MANAGE", callback_data="btn_manage")
    )
    keyboard.add(InlineKeyboardButton(text="🔎 HOW TO USE", callback_data="btn_help"))
    return keyboard

def get_voting_interface(contest_id: str, participants: list) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(row_width=1)
    for p in participants:
        btn_text = f"Vote for {p['name']} 🗳️ ({p['votes']} Votes)"
        callback_payload = f"vote_{contest_id}_{p['id']}"
        keyboard.add(InlineKeyboardButton(text=btn_text, callback_data=callback_payload))
    return keyboard
