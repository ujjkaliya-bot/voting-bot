from config.database import db
from datetime import datetime

async def cast_vote(user_id: int, contest_id: str, participant_id: str) -> dict:
    """
    Registers a vote with strict anti-cheat layers.
    Checks if user already voted in this specific contest.
    """
    # 1. Anti-Cheat Check: 1 vote per user per contest
    already_voted = await db.votes.find_one({
        "user_id": user_id,
        "contest_id": contest_id
    })
    
    if already_voted:
        return {"success": False, "msg": "⚠️ You have already casted a vote in this giveaway!"}
        
    # 2. Log the vote securely
    await db.votes.insert_one({
        "user_id": user_id,
        "contest_id": contest_id,
        "voted_for": participant_id,
        "timestamp": datetime.utcnow()
    })
    
    # 3. Dynamic Increment of vote in the contest document
    result = await db.contests.update_one(
        {"contest_id": contest_id, "participants.id": participant_id},
        {"$inc": {"participants.$.votes": 1}}
    )
    
    if result.modified_count == 0:
        # Rollback vote log if contest error occurs
        await db.votes.delete_one({"user_id": user_id, "contest_id": contest_id})
        return {"success": False, "msg": "❌ Invalid participant or inactive giveaway context."}
        
    return {"success": True, "msg": "🎉 Your vote has been securely recorded!"}
